----------------------------
A Dangerous Land (alpha 0.2)
----------------------------

Controls:
    LMB - Move
    MMB - Zoom in/out
    ESC - Pause
    M   - Toggle 'speed mode'

Known Bugs:
    - Can phase through impassible terrain at high speeds
    - Can reach empty chunks at high speeds
    - Some random seeds generate glitched worlds
    - Boarder on depressed buttons is bugged